package com.aui.dialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.app.Notification
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService

class DialerInCallService : InCallService() {
    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            CallManager.notifyChanged()
            if (state != Call.STATE_RINGING) cancelNote()
            if (state == Call.STATE_ACTIVE && !CallManager.uiUp) openUi()
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Calls", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onCallAdded(call: Call) {
        call.registerCallback(cb)
        CallManager.add(this, call)
        if (call.state == Call.STATE_RINGING) ringNote(call) else openUi()
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        CallManager.remove(call)
        cancelNote()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        CallManager.notifyChanged()
    }

    private fun uiIntent() = Intent(this, CallActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun openUi() {
        try { startActivity(uiIntent()) } catch (e: Exception) {}
    }

    private fun ringNote(call: Call) {
        val pi = PendingIntent.getActivity(this, 0, uiIntent(), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming call")
            .setContentText(call.details.handle?.schemeSpecificPart ?: "")
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    private fun cancelNote() {
        getSystemService(NotificationManager::class.java).cancel(1)
    }

    companion object { const val CH = "calls" }
}
