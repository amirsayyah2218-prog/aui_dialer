package com.aui.dialer

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.DisconnectCause
import android.telecom.InCallService

class DialerInCallService : InCallService() {
    private var ringNoted: Call? = null
    private val island by lazy { IslandOverlay(this) }
    private val islandL: () -> Unit = { island.update() }
    private val nm get() = getSystemService(NotificationManager::class.java)

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state == Call.STATE_DISCONNECTED) maybeMissed(call)
            CallManager.notifyChanged()
            sync()
            if (state == Call.STATE_ACTIVE && !CallManager.uiUp) openUi()
        }
        override fun onDetailsChanged(call: Call, details: Call.Details) { CallManager.notifyChanged() }
    }

    override fun onCreate() {
        super.onCreate()
        CallManager.listen(islandL)
        nm.createNotificationChannel(NotificationChannel(CH_IN, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        nm.createNotificationChannel(NotificationChannel(CH_ON, "Ongoing calls", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_MISSED, "Missed calls", NotificationManager.IMPORTANCE_DEFAULT))
    }

    override fun onDestroy() {
        CallManager.unlisten(islandL)
        island.hide()
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        call.registerCallback(cb)
        CallManager.add(this, call)
        if (call.state != Call.STATE_RINGING) openUi()
        sync()
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        CallManager.remove(call)
        sync()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) { CallManager.notifyChanged() }

    private fun uiIntent() = Intent(this, CallActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun ui() = PendingIntent.getActivity(this, 0, uiIntent(), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun act(action: String, code: Int, extra: (Intent) -> Unit = {}) = PendingIntent.getBroadcast(
        this, code, Intent(this, CallActionReceiver::class.java).setAction(action).also(extra),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun openUi() { try { startActivity(uiIntent()) } catch (e: Exception) {} }

    private fun nameOf(num: String): String {
        if (num.isEmpty()) return "Unknown caller"
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return num
        try {
            contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (e: Exception) {}
        return num
    }

    private fun sync() {
        val r = CallManager.ringing()
        if (r != null) { if (ringNoted !== r) { ringNoted = r; nm.notify(1, incoming(r)) } }
        else { ringNoted = null; nm.cancel(1) }
        val p = CallManager.primary()
        if (p != null && (p.state == Call.STATE_ACTIVE || p.state == Call.STATE_HOLDING || p.state == Call.STATE_DIALING || p.state == Call.STATE_CONNECTING))
            nm.notify(2, ongoing(p)) else nm.cancel(2)
    }

    @Suppress("DEPRECATION")
    private fun incoming(c: Call): Notification {
        val num = CallManager.numberOf(c)
        val name = nameOf(num)
        val full = ui()
        val answer = act(CallActionReceiver.ACT_ANSWER, 1)
        val decline = act(CallActionReceiver.ACT_DECLINE, 2)
        val b = Notification.Builder(this, CH_IN)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(name).setContentText("Incoming call")
            .setCategory(Notification.CATEGORY_CALL).setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(full).setFullScreenIntent(full, true)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setStyle(Notification.CallStyle.forIncomingCall(Person.Builder().setName(name).setImportant(true).build(), decline, answer))
        } else {
            b.addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Decline", decline).build())
            b.addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.sym_action_call), "Answer", answer).build())
        }
        return b.build()
    }

    private fun ongoing(c: Call): Notification {
        val hold = c.state == Call.STATE_HOLDING
        return Notification.Builder(this, CH_ON)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(nameOf(CallManager.numberOf(c)))
            .setContentText(if (hold) "On hold" else if (c.state == Call.STATE_ACTIVE) "Ongoing call" else "Calling…")
            .setCategory(Notification.CATEGORY_CALL).setOngoing(true)
            .setUsesChronometer(c.state == Call.STATE_ACTIVE).setWhen(CallManager.connectTime(c))
            .setContentIntent(ui())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Hang up", act(CallActionReceiver.ACT_HANGUP, 3)).build())
            .build()
    }

    private fun maybeMissed(call: Call) {
        val d = call.details
        if (d.callDirection != Call.Details.DIRECTION_INCOMING || d.disconnectCause?.code != DisconnectCause.MISSED) return
        val num = CallManager.numberOf(call)
        val id = 100 + (num.hashCode() and 0xffff)
        val open = PendingIntent.getActivity(this, 4, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val back = act(CallActionReceiver.ACT_CALLBACK, id) { it.putExtra("num", num).putExtra("nid", id) }
        nm.notify(id, Notification.Builder(this, CH_MISSED)
            .setSmallIcon(android.R.drawable.sym_call_missed)
            .setContentTitle("Missed call").setContentText(nameOf(num))
            .setCategory(Notification.CATEGORY_MISSED_CALL).setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.sym_action_call), "Call back", back).build())
            .build())
    }

    companion object { const val CH_IN = "calls_in"; const val CH_ON = "calls_on"; const val CH_MISSED = "calls_missed" }
}
