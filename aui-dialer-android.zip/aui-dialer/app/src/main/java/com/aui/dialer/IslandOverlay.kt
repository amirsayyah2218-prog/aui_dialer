package com.aui.dialer

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telecom.Call
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Floating "call island": a pill at the top of the screen while a call is ringing/ongoing and the call screen is not visible. */
class IslandOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val h = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var status: TextView? = null
    private var key = ""
    private val tick = object : Runnable { override fun run() { updateStatus(); h.postDelayed(this, 1000) } }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun update() {
        val on = ctx.getSharedPreferences("island", Context.MODE_PRIVATE).getBoolean("on", true)
        val c = CallManager.primary()
        val live = c != null && (c.state == Call.STATE_RINGING || c.state == Call.STATE_ACTIVE || c.state == Call.STATE_HOLDING ||
            c.state == Call.STATE_DIALING || c.state == Call.STATE_CONNECTING)
        if (c == null || !live || !on || !Settings.canDrawOverlays(ctx) || CallManager.uiUp) { hide(); return }
        val k = "${c.state}|${CallManager.numberOf(c)}|${CallManager.isMuted()}|${CallManager.isSpeaker()}"
        if (root == null) create()
        if (k != key) { key = k; populate(c) }
        updateStatus()
    }

    private fun create() {
        val bg = GradientDrawable().apply { cornerRadius = dp(34).toFloat(); setColor(0xEE000000.toInt()); setStroke(dp(1), 0x44FFFFFF) }
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10)); background = bg; elevation = dp(8).toFloat()
        }
        val w = minOf(ctx.resources.displayMetrics.widthPixels - dp(24), dp(420))
        val sb = ctx.resources.getIdentifier("status_bar_height", "dimen", "android").let { if (it > 0) ctx.resources.getDimensionPixelSize(it) else dp(24) }
        val lp = WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = sb + dp(4) }
        try { wm.addView(r, lp) } catch (e: Exception) { return }
        root = r
        r.alpha = 0f; r.scaleX = 0.6f; r.translationY = -dp(30).toFloat()
        r.animate().alpha(1f).scaleX(1f).translationY(0f).setDuration(300).setInterpolator(OvershootInterpolator(1.1f)).start()
        h.post(tick)
    }

    private fun populate(c: Call) {
        val r = root ?: return
        r.removeAllViews()
        val ring = c.state == Call.STATE_RINGING
        val name = Util.nameOf(ctx, CallManager.numberOf(c))
        r.addView(circle(0xFF1B3A5C.toInt(), null, name.firstOrNull()?.uppercase() ?: "#", 0))
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(10); marginEnd = dp(8) }
            setOnClickListener { open() }
        }
        col.addView(TextView(ctx).apply { text = name; setTextColor(Color.WHITE); textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        status = TextView(ctx).apply { setTextColor(0xFF9FB4CC.toInt()); textSize = 12f }
        col.addView(status)
        r.addView(col)
        if (ring) {
            r.addView(circle(0xFFE5484D.toInt(), R.drawable.ic_phone, null, 135) { CallManager.rejectRinging() })
            r.addView(circle(0xFF2FBF71.toInt(), R.drawable.ic_phone, null, 0) { CallManager.answer() })
        } else {
            r.addView(circle(if (CallManager.isMuted()) 0xFF3D9BFF.toInt() else 0x33FFFFFF, R.drawable.ic_mic, null, 0) { CallManager.mute(!CallManager.isMuted()) })
            r.addView(circle(if (CallManager.isSpeaker()) 0xFF3D9BFF.toInt() else 0x33FFFFFF, R.drawable.ic_vol, null, 0) { CallManager.speaker(!CallManager.isSpeaker()) })
            r.addView(circle(0xFFE5484D.toInt(), R.drawable.ic_phone, null, 135) { CallManager.hangup() })
        }
    }

    private fun circle(color: Int, icon: Int?, letter: String?, rot: Int, click: (() -> Unit)? = null): View {
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        val s = dp(40)
        val lp = LinearLayout.LayoutParams(s, s).apply { marginStart = dp(6) }
        return if (icon != null) ImageView(ctx).apply {
            setImageResource(icon); background = bg; setPadding(dp(9), dp(9), dp(9), dp(9)); rotation = rot.toFloat(); layoutParams = lp
            click?.let { c -> setOnClickListener { c() } }
        } else TextView(ctx).apply {
            text = letter; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; background = bg; layoutParams = lp.apply { marginStart = 0 }
        }
    }

    private fun updateStatus() {
        val c = CallManager.primary() ?: return
        status?.text = when (c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_ACTIVE -> { val s = ((System.currentTimeMillis() - CallManager.connectTime(c)) / 1000).coerceAtLeast(0); String.format("%02d:%02d", s / 60, s % 60) }
            else -> "Calling…"
        }
    }

    private fun open() {
        try { ctx.startActivity(Intent(ctx, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (e: Exception) {}
    }

    fun hide() {
        h.removeCallbacks(tick)
        root?.let { try { wm.removeViewImmediate(it) } catch (e: Exception) {} }
        root = null; key = ""
    }
}
