package com.aui.dialer

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.TelecomManager
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Full-screen incoming / ongoing call UI. Shows over the lock screen and wakes the display. */
class CallActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var bridge: Bridge
    private var prox: PowerManager.WakeLock? = null
    private val listener: () -> Unit = { push() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.note(this, "CallActivity created")
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 31) {
            // blur the wallpaper / whatever is behind the call screen
            try {
                window.setBackgroundBlurRadius(170)
                window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND or WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                val lp = window.attributes
                lp.blurBehindRadius = 120
                lp.dimAmount = 0.25f
                window.attributes = lp
            } catch (e: Throwable) { CrashLog.save(this, e) }
        }
        web = WebView(this)
        setContentView(web)
        bridge = Bridge(this, true)
        Web.setup(web, bridge, true) { push() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })
    }

    override fun onStart() {
        super.onStart()
        CallManager.uiUp = true
        CallManager.listen(listener)
        push()
    }

    override fun onStop() {
        CallManager.uiUp = false
        CallManager.unlisten(listener)
        setProx(false)
        super.onStop()
    }

    override fun onDestroy() { if (::bridge.isInitialized) bridge.release(); super.onDestroy() }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); push() }

    // Volume key silences the ringer, like the stock dialer.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && CallManager.isRinging()) {
            try { getSystemService(TelecomManager::class.java).silenceRinger() } catch (e: Exception) {}
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun setProx(on: Boolean) {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) return
        if (on) {
            if (prox == null) prox = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "aui:prox")
            if (prox?.isHeld != true) prox?.acquire(4 * 60 * 60 * 1000L)
        } else if (prox?.isHeld == true) prox?.release()
    }

    private fun push() = runOnUiThread {
        web.evaluateJavascript("window.nativeCall&&window.nativeCall(${CallManager.state()})", null)
        setProx(CallManager.proximityWanted())
    }
}
