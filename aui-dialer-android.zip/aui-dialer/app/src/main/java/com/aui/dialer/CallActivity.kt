package com.aui.dialer

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Full-screen incoming / ongoing call UI, driven by CallManager. */
class CallActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val listener: () -> Unit = { push() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        setContentView(web)
        Web.setup(web, Bridge(this, true)) { push() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })
    }

    override fun onStart() {
        super.onStart()
        CallManager.uiUp = true
        CallManager.listen(listener)
        push()
    }

    override fun onStop() {
        CallManager.uiUp = false
        CallManager.unlisten(listener)
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        push()
    }

    private fun push() = runOnUiThread {
        web.evaluateJavascript("window.nativeCall&&window.nativeCall(${CallManager.state()})", null)
    }
}
