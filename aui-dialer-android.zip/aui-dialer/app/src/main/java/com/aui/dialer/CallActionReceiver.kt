package com.aui.dialer

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager

/** Handles notification buttons: Answer / Decline / Hang up / Call back. */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            ACT_ANSWER -> CallManager.answer()
            ACT_DECLINE -> CallManager.rejectRinging()
            ACT_HANGUP -> CallManager.hangup()
            ACT_CALLBACK -> {
                val n = i.getStringExtra("num") ?: return
                c.getSystemService(NotificationManager::class.java).cancel(i.getIntExtra("nid", 0))
                try { c.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", n, null), Bundle()) }
                catch (e: SecurityException) {}
            }
        }
    }
    companion object {
        const val ACT_ANSWER = "com.aui.dialer.ANSWER"
        const val ACT_DECLINE = "com.aui.dialer.DECLINE"
        const val ACT_HANGUP = "com.aui.dialer.HANGUP"
        const val ACT_CALLBACK = "com.aui.dialer.CALLBACK"
    }
}
