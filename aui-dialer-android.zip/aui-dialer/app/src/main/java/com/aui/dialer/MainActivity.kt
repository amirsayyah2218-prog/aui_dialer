package com.aui.dialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var loaded = false
    private var pendingDial: String? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        js("window.loadNative&&window.loadNative()")
        askRole(false)
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        js("window.loadNative&&window.loadNative()")
    }

    private val perms: List<String> get() = buildList {
        add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.WRITE_CONTACTS)
        add(Manifest.permission.READ_CALL_LOG); add(Manifest.permission.WRITE_CALL_LOG)
        add(Manifest.permission.CALL_PHONE); add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        Web.setup(web, Bridge(this, false)) {
            loaded = true
            pendingDial?.let { dial(it) }
            pendingDial = null
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.nativeBack&&window.nativeBack())?1:0") { if (it != "1") finish() }
            }
        })
        handle(intent)
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray()) else askRole(false)
    }

    override fun onResume() {
        super.onResume()
        js("window.loadNative&&window.loadNative()")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val n = i?.data?.takeIf { it.scheme == "tel" }?.schemeSpecificPart ?: return
        if (loaded) dial(n) else pendingDial = n
    }

    private fun dial(n: String) = js("window.nativeDial&&window.nativeDial(${JSONObject.quote(n)})")
    private fun js(s: String) = web.evaluateJavascript(s, null)

    fun askRole(force: Boolean) {
        val rm = getSystemService(RoleManager::class.java)
        if (!rm.isRoleAvailable(RoleManager.ROLE_DIALER) || rm.isRoleHeld(RoleManager.ROLE_DIALER)) return
        val p = getPreferences(MODE_PRIVATE)
        if (!force && p.getBoolean("asked", false)) return
        p.edit().putBoolean("asked", true).apply()
        roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
    }
}
