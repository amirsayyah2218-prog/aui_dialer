package com.aui.dialer

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var loaded = false
    private var pendingDial: String? = null
    private val prefs by lazy { getPreferences(MODE_PRIVATE) }
    private val callListener: () -> Unit = {
        runOnUiThread { js("window.nativeBanner&&window.nativeBanner(${CallManager.state()})") }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        js("window.loadNative&&window.loadNative()")
        val blocked = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED && !shouldShowRequestPermissionRationale(it) }
        if (blocked.isNotEmpty()) {
            AlertDialog.Builder(this).setTitle("Permissions needed")
                .setMessage("Calling, contacts and call history won't work until you allow Phone, Contacts, Call log and SMS access in Settings.")
                .setPositiveButton("Open settings") { _, _ -> openAppSettings() }
                .setNegativeButton("Later") { _, _ -> afterPerms() }.show()
        } else afterPerms()
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        js("window.loadNative&&window.loadNative()")
        askFsi()
    }

    private val perms: List<String> get() = buildList {
        add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.WRITE_CONTACTS)
        add(Manifest.permission.READ_CALL_LOG); add(Manifest.permission.WRITE_CALL_LOG)
        add(Manifest.permission.CALL_PHONE); add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        Web.setup(web, Bridge(this, false)) {
            loaded = true
            pendingDial?.let { dial(it) }
            pendingDial = null
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.nativeBack&&window.nativeBack())?1:0") { if (it != "1") finish() }
            }
        })
        handle(intent)
        startFlow()
    }

    override fun onStart() { super.onStart(); CallManager.listen(callListener); callListener() }
    override fun onStop() { CallManager.unlisten(callListener); super.onStop() }
    override fun onResume() { super.onResume(); js("window.loadNative&&window.loadNative()") }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra("add", false) == true) { if (loaded) dial("") else pendingDial = ""; return }
        val n = i?.data?.takeIf { it.scheme == "tel" }?.schemeSpecificPart ?: return
        if (loaded) dial(n) else pendingDial = n
    }

    private fun dial(n: String) = js("window.nativeDial&&window.nativeDial(${JSONObject.quote(n)})")
    private fun js(s: String) = web.evaluateJavascript(s, null)

    // ---- first-run setup: permissions → default phone app → lock-screen alerts ----
    private fun startFlow() {
        if (prefs.getBoolean("onb", false)) { requestPerms(); return }
        AlertDialog.Builder(this).setTitle("Set up AUI Dialer").setCancelable(false)
            .setMessage("To make and receive calls, AUI Dialer needs:\n\n• Phone – place and manage calls\n• Contacts & Call log – names, recents\n• SMS – reply to callers with a message\n• Notifications – incoming and missed call alerts\n\nNext you'll be asked to make it your default phone app so incoming calls show on the lock screen.")
            .setPositiveButton("Continue") { _, _ -> prefs.edit().putBoolean("onb", true).apply(); requestPerms() }.show()
    }

    private fun requestPerms() {
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray()) else afterPerms()
    }

    private fun afterPerms() { if (!askRole(false)) askFsi() }

    /** Returns true if the system role dialog was launched. */
    fun askRole(force: Boolean): Boolean {
        val rm = getSystemService(RoleManager::class.java)
        if (!rm.isRoleAvailable(RoleManager.ROLE_DIALER) || rm.isRoleHeld(RoleManager.ROLE_DIALER)) return false
        if (!force && prefs.getBoolean("asked", false)) return false
        prefs.edit().putBoolean("asked", true).apply()
        roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        return true
    }

    private fun askFsi() {
        if (Build.VERSION.SDK_INT < 34) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.canUseFullScreenIntent() || prefs.getBoolean("fsi", false)) return
        prefs.edit().putBoolean("fsi", true).apply()
        AlertDialog.Builder(this).setTitle("Show calls on the lock screen")
            .setMessage("Allow full-screen notifications so incoming calls appear when your phone is locked or the screen is off.")
            .setPositiveButton("Allow") { _, _ -> openFsiSettings() }.setNegativeButton("Not now", null).show()
    }

    fun openFsiSettings() {
        val i = if (Build.VERSION.SDK_INT >= 34) Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
        else Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        try { startActivity(i) } catch (e: Exception) { openAppSettings() }
    }

    fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }
}
