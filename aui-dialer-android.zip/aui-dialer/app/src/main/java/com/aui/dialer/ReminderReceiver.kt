package com.aui.dialer

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/** "Remind me to call" alarms: fires a notification with a Call button; survives reboot. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            ACT_FIRE -> fire(c, i.getStringExtra("id") ?: "", i.getStringExtra("num") ?: "", i.getStringExtra("name") ?: "", i.getStringExtra("note") ?: "")
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                val a = load(c)
                for (k in 0 until a.length()) {
                    val o = a.getJSONObject(k)
                    val ts = o.getLong("ts")
                    if (ts <= System.currentTimeMillis()) fire(c, o.getString("id"), o.getString("num"), o.getString("name"), o.optString("note"))
                    else set(c, o.getString("id"), ts, o.getString("num"), o.getString("name"), o.optString("note"))
                }
            }
        }
    }

    private fun fire(c: Context, id: String, num: String, name: String, note: String) {
        store(c, without(load(c), id))
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Call reminders", NotificationManager.IMPORTANCE_HIGH))
        val nid = 500 + (id.hashCode() and 0xffff)
        val open = PendingIntent.getActivity(c, nid, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val call = PendingIntent.getBroadcast(c, nid, Intent(c, CallActionReceiver::class.java).setAction(CallActionReceiver.ACT_CALLBACK).putExtra("num", num).putExtra("nid", nid), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(nid, Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Time to call " + name.ifEmpty { num })
            .setContentText(if (note.isNotEmpty()) note else num)
            .setCategory(Notification.CATEGORY_REMINDER).setAutoCancel(true).setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.sym_action_call), "Call", call).build())
            .build())
    }

    companion object {
        const val ACT_FIRE = "com.aui.dialer.REMINDER"
        private const val CH = "reminders"
        private fun prefs(c: Context) = c.getSharedPreferences("rem", Context.MODE_PRIVATE)
        private fun load(c: Context): JSONArray = try { JSONArray(prefs(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        private fun store(c: Context, a: JSONArray) { prefs(c).edit().putString("list", a.toString()).apply() }
        private fun without(a: JSONArray, id: String): JSONArray {
            val o = JSONArray()
            for (k in 0 until a.length()) if (a.getJSONObject(k).getString("id") != id) o.put(a.getJSONObject(k))
            return o
        }
        private fun pi(c: Context, id: String, num: String, name: String, note: String): PendingIntent = PendingIntent.getBroadcast(
            c, id.hashCode(),
            Intent(c, ReminderReceiver::class.java).setAction(ACT_FIRE).putExtra("id", id).putExtra("num", num).putExtra("name", name).putExtra("note", note),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        private fun set(c: Context, id: String, ts: Long, num: String, name: String, note: String) {
            val am = c.getSystemService(AlarmManager::class.java)
            val p = pi(c, id, num, name, note)
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p)
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p)
            } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p) }
        }

        fun schedule(c: Context, id: String, ts: Long, num: String, name: String, note: String) {
            store(c, without(load(c), id).put(JSONObject().put("id", id).put("ts", ts).put("num", num).put("name", name).put("note", note)))
            set(c, id, ts, num, name, note)
        }

        fun cancel(c: Context, id: String) {
            store(c, without(load(c), id))
            c.getSystemService(AlarmManager::class.java).cancel(PendingIntent.getBroadcast(
                c, id.hashCode(), Intent(c, ReminderReceiver::class.java).setAction(ACT_FIRE), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
    }
}
