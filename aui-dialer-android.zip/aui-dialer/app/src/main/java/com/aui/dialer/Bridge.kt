package com.aui.dialer

import android.Manifest
import android.app.Activity
import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telecom.TelecomManager
import android.webkit.JavascriptInterface
import androidx.core.view.WindowCompat
import org.json.JSONArray
import org.json.JSONObject

/** Native functions exposed to the web UI as window.AuiBridge. */
class Bridge(private val act: Activity, private val callMode: Boolean) {
    private val ctx: Context = act.applicationContext
    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun ui(f: () -> Unit) = act.runOnUiThread(f)
    private fun launch(i: Intent) = ui { try { act.startActivity(i) } catch (e: Exception) {} }
    private fun clean(n: String) = n.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }

    @JavascriptInterface fun isCallMode() = callMode

    // ---- data ----
    @JavascriptInterface fun getContacts(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_CONTACTS)) return out.toString()
        val mails = HashMap<String, String>()
        ctx.contentResolver.query(Email.CONTENT_URI, arrayOf(Email.CONTACT_ID, Email.ADDRESS), null, null, null)?.use { c ->
            while (c.moveToNext()) mails.putIfAbsent(c.getString(0) ?: continue, c.getString(1) ?: "")
        }
        val seen = HashSet<String>()
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, ContactsContract.Contacts.STARRED),
            null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                if (!seen.add(id)) continue
                out.put(JSONObject().put("id", id).put("name", c.getString(1) ?: "")
                    .put("phone", c.getString(2) ?: "").put("fav", c.getInt(3)).put("email", mails[id] ?: ""))
            }
        }
        return out.toString()
    }

    @JavascriptInterface fun getCallLog(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_CALL_LOG)) return out.toString()
        val args = Bundle().apply {
            putInt(ContentResolver.QUERY_ARG_LIMIT, 300)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(CallLog.Calls.DATE))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
            args, null
        )?.use { c ->
            while (c.moveToNext()) {
                val t = when (c.getInt(2)) {
                    CallLog.Calls.OUTGOING_TYPE -> "out"
                    CallLog.Calls.INCOMING_TYPE, CallLog.Calls.VOICEMAIL_TYPE -> "in"
                    else -> "miss"
                }
                out.put(JSONObject().put("id", c.getString(0)).put("num", c.getString(1)?.ifEmpty { "Unknown" } ?: "Unknown")
                    .put("type", t).put("ts", c.getLong(3)).put("dur", if (t == "miss") 0 else c.getLong(4)))
            }
        }
        return out.toString()
    }

    @JavascriptInterface fun getBlocked(): String {
        val out = JSONArray()
        try {
            ctx.contentResolver.query(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null)?.use { c ->
                while (c.moveToNext()) out.put(c.getString(0))
            }
        } catch (e: Exception) {}
        return out.toString()
    }

    // ---- calls ----
    @JavascriptInterface fun placeCall(n: String) = ui {
        if (!has(Manifest.permission.CALL_PHONE)) { act.requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 7); return@ui }
        try { ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", clean(n), null), Bundle()) }
        catch (e: SecurityException) {}
    }
    @JavascriptInterface fun answer() = ui { CallManager.answer() }
    @JavascriptInterface fun hangup() = ui { CallManager.hangup() }
    @JavascriptInterface fun rejectWithMessage(t: String) = ui { CallManager.rejectWithMessage(t) }
    @JavascriptInterface fun setMute(b: Boolean) = ui { CallManager.mute(b) }
    @JavascriptInterface fun setSpeaker(b: Boolean) = ui { CallManager.speaker(b) }
    @JavascriptInterface fun setHold(b: Boolean) = ui { CallManager.hold(b) }
    @JavascriptInterface fun dtmf(k: String) = ui { CallManager.dtmf(k) }

    // ---- contacts / messages ----
    @JavascriptInterface fun sms(n: String) = launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(clean(n)))))
    @JavascriptInterface fun newContact(phone: String) = launch(Intent(ContactsContract.Intents.Insert.ACTION).apply {
        type = ContactsContract.RawContacts.CONTENT_TYPE
        if (phone.isNotEmpty()) putExtra(ContactsContract.Intents.Insert.PHONE, phone)
    })
    @JavascriptInterface fun editContact(id: String) =
        launch(Intent(Intent.ACTION_EDIT, ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id.toLong())))
    @JavascriptInterface fun setFav(id: String, fav: Boolean) {
        try {
            ctx.contentResolver.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id.toLong()),
                ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (fav) 1 else 0) }, null, null)
        } catch (e: Exception) {}
    }
    @JavascriptInterface fun deleteContact(id: String) {
        try { ctx.contentResolver.delete(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id.toLong()), null, null) }
        catch (e: Exception) {}
    }
    @JavascriptInterface fun setBlocked(n: String, on: Boolean) {
        try {
            if (on) ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n) })
            else BlockedNumberContract.unblock(ctx, n)
        } catch (e: Exception) {}
    }
    @JavascriptInterface fun deleteLog(id: String) {
        try { ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "${CallLog.Calls._ID}=?", arrayOf(id)) } catch (e: Exception) {}
    }
    @JavascriptInterface fun clearLog() {
        try { ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null) } catch (e: Exception) {}
    }

    // ---- app ----
    @JavascriptInterface fun requestDefault() = ui { (act as? MainActivity)?.askRole(true) }
    @JavascriptInterface fun finish() = ui { act.finish() }
    @JavascriptInterface fun setBars(light: Boolean) = ui {
        val c = if (light) 0xFFF2F6FB.toInt() else Color.BLACK
        act.window.statusBarColor = c
        act.window.navigationBarColor = c
        WindowCompat.getInsetsController(act.window, act.window.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }
}
