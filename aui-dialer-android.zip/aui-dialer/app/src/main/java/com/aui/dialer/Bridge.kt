package com.aui.dialer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.PhoneNumberUtils
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.view.WindowCompat
import android.content.ContentProviderOperation
import android.content.Intent as I2
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

/** Native functions exposed to the web UI as window.AuiBridge. */
@Suppress("DEPRECATION")
class Bridge(private val act: Activity, private val callMode: Boolean) {
    var web: WebView? = null
    private val ctx: Context = act.applicationContext
    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun ui(f: () -> Unit) = act.runOnUiThread(f)
    private fun launch(i: Intent) = ui { try { act.startActivity(i) } catch (e: Exception) {} }
    private fun clean(n: String) = n.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
    private val tg: ToneGenerator? by lazy { try { ToneGenerator(AudioManager.STREAM_DTMF, 70) } catch (e: Exception) { null } }

    @JavascriptInterface fun isCallMode() = callMode

    // ---- data ----
    @JavascriptInterface fun getContacts(): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return "[]"
        val mails = HashMap<String, String>()
        ctx.contentResolver.query(Email.CONTENT_URI, arrayOf(Email.CONTACT_ID, Email.ADDRESS), null, null, null)?.use { c ->
            while (c.moveToNext()) mails.putIfAbsent(c.getString(0) ?: continue, c.getString(1) ?: "")
        }
        val map = LinkedHashMap<String, JSONObject>()
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, ContactsContract.Contacts.STARRED),
            null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val num = c.getString(2) ?: continue
                val o = map.getOrPut(id) {
                    JSONObject().put("id", id).put("name", c.getString(1) ?: "").put("phone", num)
                        .put("fav", c.getInt(3)).put("email", mails[id] ?: "").put("ph", JSONArray())
                }
                val ph = o.getJSONArray("ph")
                val k = num.filter { it.isDigit() }.takeLast(10)
                if ((0 until ph.length()).none { ph.getString(it).filter { d -> d.isDigit() }.takeLast(10) == k }) ph.put(num)
            }
        }
        return JSONArray(map.values).toString()
    }

    /** Contact thumbnails, delivered asynchronously via window.onPhotos. */
    @JavascriptInterface fun requestPhotos() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val m = JSONObject()
            try {
                ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.CONTACT_ID, Phone.PHOTO_THUMBNAIL_URI), null, null, null)?.use { c ->
                    while (c.moveToNext() && m.length() < 400) {
                        val id = c.getString(0) ?: continue
                        val u = c.getString(1) ?: continue
                        if (m.has(id)) continue
                        try {
                            ctx.contentResolver.openInputStream(Uri.parse(u))?.use { s ->
                                val b = s.readBytes()
                                if (b.size < 40000) m.put(id, "data:image/jpeg;base64," + Base64.encodeToString(b, Base64.NO_WRAP))
                            }
                        } catch (e: Exception) {}
                    }
                }
            } catch (e: Exception) {}
            act.runOnUiThread { web?.evaluateJavascript("window.onPhotos&&window.onPhotos($m)", null) }
        }.start()
    }

    @JavascriptInterface fun getCallLog(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_CALL_LOG)) return out.toString()
        val args = Bundle().apply {
            putInt(ContentResolver.QUERY_ARG_LIMIT, 300)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(CallLog.Calls.DATE))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
            args, null
        )?.use { c ->
            while (c.moveToNext()) {
                val t = when (c.getInt(2)) {
                    CallLog.Calls.OUTGOING_TYPE -> "out"
                    CallLog.Calls.INCOMING_TYPE, CallLog.Calls.VOICEMAIL_TYPE -> "in"
                    else -> "miss"
                }
                out.put(JSONObject().put("id", c.getString(0)).put("num", c.getString(1)?.ifEmpty { "Unknown" } ?: "Unknown")
                    .put("type", t).put("ts", c.getLong(3)).put("dur", if (t == "miss") 0 else c.getLong(4)))
            }
        }
        return out.toString()
    }

    @JavascriptInterface fun getBlocked(): String {
        val out = JSONArray()
        try {
            ctx.contentResolver.query(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null)?.use { c ->
                while (c.moveToNext()) out.put(c.getString(0))
            }
        } catch (e: Exception) {}
        return out.toString()
    }

    // ---- placing calls (with SIM chooser on dual-SIM phones) ----
    @JavascriptInterface fun placeCall(n: String) = ui {
        if (!has(Manifest.permission.CALL_PHONE)) { act.requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 7); return@ui }
        val num = clean(n)
        if (num.isEmpty()) return@ui
        val tm = ctx.getSystemService(TelecomManager::class.java)
        val uri = Uri.fromParts("tel", num, null)
        val accts: List<PhoneAccountHandle> = try {
            if (has(Manifest.permission.READ_PHONE_STATE)) tm.callCapablePhoneAccounts else emptyList()
        } catch (e: Exception) { emptyList() }
        if (accts.size > 1 && !PhoneNumberUtils.isEmergencyNumber(num)) {
            val labels = accts.map { tm.getPhoneAccount(it)?.label?.toString() ?: "SIM" }.toTypedArray()
            AlertDialog.Builder(act).setTitle("Call with").setItems(labels) { _, i -> dialOn(tm, uri, accts[i]) }.show()
        } else dialOn(tm, uri, null)
    }

    private fun dialOn(tm: TelecomManager, uri: Uri, h: PhoneAccountHandle?) {
        val ex = Bundle()
        if (h != null) ex.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h)
        try { tm.placeCall(uri, ex) } catch (e: SecurityException) {}
    }

    @JavascriptInterface fun voicemail() = ui {
        try { ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts(PhoneAccount.SCHEME_VOICEMAIL, "", null), Bundle()) }
        catch (e: Exception) {}
    }

    // ---- in-call controls ----
    @JavascriptInterface fun answer() = ui { CallManager.answer() }
    @JavascriptInterface fun hangup() = ui { CallManager.hangup() }
    @JavascriptInterface fun rejectWithMessage(t: String) = ui { CallManager.rejectWithMessage(t) }
    @JavascriptInterface fun answerWaiting() = ui { CallManager.answerWaiting() }
    @JavascriptInterface fun declineWaiting() = ui { CallManager.rejectRinging() }
    @JavascriptInterface fun swap() = ui { CallManager.swap() }
    @JavascriptInterface fun merge() = ui { CallManager.merge() }
    @JavascriptInterface fun setMute(b: Boolean) = ui { CallManager.mute(b) }
    @JavascriptInterface fun setSpeaker(b: Boolean) = ui { CallManager.speaker(b) }
    @JavascriptInterface fun setRoute(r: String) = ui { CallManager.setRoute(r) }
    @JavascriptInterface fun setHold(b: Boolean) = ui { CallManager.hold(b) }
    @JavascriptInterface fun dtmf(k: String) = ui { CallManager.dtmf(k) }
    @JavascriptInterface fun tone(k: String) {
        val t = when (k) {
            "0" -> ToneGenerator.TONE_DTMF_0; "1" -> ToneGenerator.TONE_DTMF_1; "2" -> ToneGenerator.TONE_DTMF_2
            "3" -> ToneGenerator.TONE_DTMF_3; "4" -> ToneGenerator.TONE_DTMF_4; "5" -> ToneGenerator.TONE_DTMF_5
            "6" -> ToneGenerator.TONE_DTMF_6; "7" -> ToneGenerator.TONE_DTMF_7; "8" -> ToneGenerator.TONE_DTMF_8
            "9" -> ToneGenerator.TONE_DTMF_9; "*" -> ToneGenerator.TONE_DTMF_S; "#" -> ToneGenerator.TONE_DTMF_P
            else -> return
        }
        tg?.startTone(t, 120)
    }
    @JavascriptInterface fun addCall() = launch(Intent(act, MainActivity::class.java).putExtra("add", true)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    @JavascriptInterface fun returnToCall() = launch(Intent(act, CallActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))

    // ---- contacts / messages ----
    @JavascriptInterface fun sms(n: String) = launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(clean(n)))))
    @JavascriptInterface fun newContact(phone: String) = launch(Intent(ContactsContract.Intents.Insert.ACTION).apply {
        type = ContactsContract.RawContacts.CONTENT_TYPE
        if (phone.isNotEmpty()) putExtra(ContactsContract.Intents.Insert.PHONE, phone)
    })
    @JavascriptInterface fun editContact(id: String) =
        launch(Intent(Intent.ACTION_EDIT, ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id.toLong())))
    @JavascriptInterface fun setFav(id: String, fav: Boolean) {
        try {
            ctx.contentResolver.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id.toLong()),
                ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (fav) 1 else 0) }, null, null)
        } catch (e: Exception) {}
    }
    @JavascriptInterface fun deleteContact(id: String) {
        try { ctx.contentResolver.delete(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id.toLong()), null, null) }
        catch (e: Exception) {}
    }
    @JavascriptInterface fun setBlocked(n: String, on: Boolean) {
        try {
            if (on) ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n) })
            else BlockedNumberContract.unblock(ctx, n)
        } catch (e: Exception) {}
    }
    @JavascriptInterface fun deleteLog(id: String) {
        try { ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "${CallLog.Calls._ID}=?", arrayOf(id)) } catch (e: Exception) {}
    }
    @JavascriptInterface fun clearLog() {
        try { ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null) } catch (e: Exception) {}
    }

    // ---- app ----
    @JavascriptInterface fun requestDefault() = ui { (act as? MainActivity)?.askRole(true) }
    @JavascriptInterface fun openFsiSettings() = ui { (act as? MainActivity)?.openFsiSettings() }
    @JavascriptInterface fun openAppSettings() = ui { (act as? MainActivity)?.openAppSettings() }
    @JavascriptInterface fun finish() = ui { act.finish() }
    @JavascriptInterface fun setBars(light: Boolean) = ui {
        val c = if (light) 0xFFF2F6FB.toInt() else Color.BLACK
        act.window.statusBarColor = c
        act.window.navigationBarColor = c
        WindowCompat.getInsetsController(act.window, act.window.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }

    // ---- voice: speech recognition (assistant + call notes) and text-to-speech ----
    private var rec: SpeechRecognizer? = null
    private var recMode = ""
    private var recTag = "en-US"
    private var want = false
    private val hh = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private fun jsCall(s: String) = act.runOnUiThread { web?.evaluateJavascript(s, null) }
    private fun deliver(t: String, fin: Boolean) =
        jsCall("window.onSpeech&&window.onSpeech({mode:'$recMode',final:$fin,text:${JSONObject.quote(t)}})")

    @JavascriptInterface fun listen(tag: String, mode: String) = ui {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9)
            jsCall("window.onSpeechError&&window.onSpeechError('perm')"); return@ui
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { jsCall("window.onSpeechError&&window.onSpeechError('na')"); return@ui }
        stopRecOnly(); recMode = mode; recTag = tag; want = true; startRec()
    }

    @JavascriptInterface fun stopListen() = ui { want = false; stopRecOnly() }

    private fun stopRecOnly() { try { rec?.stopListening(); rec?.destroy() } catch (e: Exception) {}; rec = null }
    private fun restart() { stopRecOnly(); hh.postDelayed({ if (want) startRec() }, 250) }

    private fun startRec() {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { deliver(it, false) }
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) deliver(t, true)
                if (recMode == "note" && want) hh.post { restart() } else want = false
            }
            override fun onError(e: Int) {
                if (recMode == "note" && want && (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) hh.post { restart() }
                else { want = false; jsCall("window.onSpeechError&&window.onSpeechError('$e')") }
            }
        })
        r.startListening(I2(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, recTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName))
    }

    @JavascriptInterface fun speak(text: String, tag: String) = ui {
        val go: () -> Unit = {
            tts?.language = Locale.forLanguageTag(tag)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "va")
        }
        if (tts == null) tts = TextToSpeech(ctx) { ttsReady = it == TextToSpeech.SUCCESS; if (ttsReady) go() }
        else if (ttsReady) go()
    }

    fun release() { want = false; stopRecOnly(); try { tts?.shutdown() } catch (e: Exception) {}; tts = null }

    // ---- save a contact directly (voice assistant) ----
    @JavascriptInterface fun addContact(name: String, phone: String): Boolean {
        if (!has(Manifest.permission.WRITE_CONTACTS)) return false
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null).withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.DISPLAY_NAME, name).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
            .withValue(Phone.NUMBER, phone).withValue(Phone.TYPE, Phone.TYPE_MOBILE).build())
        return try { ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops); true } catch (e: Exception) { false }
    }

    // ---- reminders ----
    @JavascriptInterface fun scheduleReminder(id: String, ts: Long, num: String, name: String, note: String) =
        ReminderReceiver.schedule(ctx, id, ts, num, name, note)
    @JavascriptInterface fun cancelReminder(id: String) = ReminderReceiver.cancel(ctx, id)

    // ---- floating island ----
    @JavascriptInterface fun setIsland(on: Boolean) {
        ctx.getSharedPreferences("island", Context.MODE_PRIVATE).edit().putBoolean("on", on).apply()
        ui { CallManager.notifyChanged() }
    }
    @JavascriptInterface fun canOverlay() = Settings.canDrawOverlays(ctx)
    @JavascriptInterface fun openOverlaySettings() = ui { (act as? MainActivity)?.openOverlaySettings() }
    @JavascriptInterface fun showDiagnostics() = ui { (act as? MainActivity)?.showDiag() }
}
