package com.aui.dialer

import android.app.Application
import android.content.Context
import android.util.Log

/** Tiny on-device diagnostics: keeps the last crash and a short "trail" of call events. */
object CrashLog {
    private fun p(c: Context) = c.getSharedPreferences("diag", Context.MODE_PRIVATE)

    fun save(c: Context, t: Throwable) {
        try { p(c).edit().putString("crash", Log.getStackTraceString(t).take(5000)).putBoolean("unseen", true).commit() } catch (e: Exception) {}
    }
    fun note(c: Context, msg: String) {
        try {
            val old = p(c).getString("trail", "") ?: ""
            val line = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + " " + msg + "\n"
            p(c).edit().putString("trail", (old + line).takeLast(1800)).commit()
        } catch (e: Exception) {}
    }
    fun trail(c: Context): String = p(c).getString("trail", "") ?: ""
    fun last(c: Context): String? = p(c).getString("crash", null)
    fun unseen(c: Context): Boolean = p(c).getBoolean("unseen", false) && last(c) != null
    fun seen(c: Context) { p(c).edit().putBoolean("unseen", false).apply() }
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            CrashLog.save(this, e)
            prev?.uncaughtException(t, e)
        }
    }
}
