package com.aui.dialer

import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import org.json.JSONArray
import org.json.JSONObject

/** Tracks all telecom calls (call waiting, hold, swap, conference) and exposes JSON state for the UI. */
@Suppress("DEPRECATION")
object CallManager {
    private val calls = ArrayList<Call>()
    private var svc: InCallService? = null
    private val t0s = HashMap<Call, Long>()
    private val listeners = LinkedHashSet<() -> Unit>()
    var uiUp = false
        set(v) { if (field != v) { field = v; notifyChanged() } }

    fun listen(l: () -> Unit) { listeners.add(l) }
    fun unlisten(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { listeners.toList().forEach { it() } }

    fun add(s: InCallService, c: Call) { svc = s; if (!calls.contains(c)) calls.add(c); notifyChanged() }
    fun remove(c: Call) { calls.remove(c); t0s.remove(c); notifyChanged() }

    fun top(): List<Call> = calls.filter { it.parent == null }
    fun hasCall() = top().isNotEmpty()
    fun ringing(): Call? = top().firstOrNull { it.state == Call.STATE_RINGING }
    fun isRinging() = ringing() != null
    fun numberOf(c: Call): String = c.details.handle?.schemeSpecificPart ?: ""
    fun connectTime(c: Call): Long = t0s[c] ?: System.currentTimeMillis()

    fun primary(): Call? {
        val t = top()
        return t.firstOrNull { it.state == Call.STATE_ACTIVE }
            ?: t.firstOrNull { it.state == Call.STATE_DIALING || it.state == Call.STATE_CONNECTING || it.state == Call.STATE_PULLING_CALL || it.state == Call.STATE_SELECT_PHONE_ACCOUNT }
            ?: t.firstOrNull { it.state == Call.STATE_RINGING }
            ?: t.firstOrNull { it.state == Call.STATE_HOLDING }
            ?: t.firstOrNull()
    }

    fun isMuted() = svc?.callAudioState?.isMuted == true
    fun isSpeaker() = svc?.callAudioState?.route == CallAudioState.ROUTE_SPEAKER

    fun answer() { ringing()?.answer(VideoProfile.STATE_AUDIO_ONLY) }
    fun rejectRinging() { ringing()?.reject(false, null) }
    fun rejectWithMessage(t: String) { ringing()?.reject(true, t) }
    fun hangup() {
        val c = primary() ?: return
        if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
    }
    fun answerWaiting() {
        val r = ringing() ?: return
        top().firstOrNull { it.state == Call.STATE_ACTIVE }?.hold()
        r.answer(VideoProfile.STATE_AUDIO_ONLY)
    }
    fun swap() {
        top().firstOrNull { it.state == Call.STATE_ACTIVE }?.hold()
        top().firstOrNull { it.state == Call.STATE_HOLDING }?.unhold()
    }
    fun merge() {
        val a = top().firstOrNull { it.state == Call.STATE_ACTIVE } ?: return
        val h = top().firstOrNull { it.state == Call.STATE_HOLDING }
        if ((a.details.callCapabilities and Call.Details.CAPABILITY_MERGE_CONFERENCE) != 0) a.mergeConference()
        else if (h != null) a.conference(h)
    }
    fun hold(on: Boolean) { val c = primary() ?: return; if (on) c.hold() else c.unhold() }
    fun mute(on: Boolean) { svc?.setMuted(on) }
    fun setRoute(name: String) {
        val r = when (name) {
            "ear" -> CallAudioState.ROUTE_EARPIECE
            "wired" -> CallAudioState.ROUTE_WIRED_HEADSET
            "bt" -> CallAudioState.ROUTE_BLUETOOTH
            "spk" -> CallAudioState.ROUTE_SPEAKER
            else -> return
        }
        svc?.setAudioRoute(r)
    }
    fun speaker(on: Boolean) = setRoute(if (on) "spk" else "ear")
    fun dtmf(k: String) {
        val c = primary() ?: return
        val ch = k.firstOrNull() ?: return
        c.playDtmfTone(ch)
        Handler(Looper.getMainLooper()).postDelayed({ c.stopDtmfTone() }, 150)
    }

    /** Turn the screen off near the ear while talking on the earpiece. */
    fun proximityWanted(): Boolean {
        val c = primary() ?: return false
        val live = c.state == Call.STATE_ACTIVE || c.state == Call.STATE_DIALING || c.state == Call.STATE_CONNECTING
        return live && svc?.callAudioState?.route == CallAudioState.ROUTE_EARPIECE
    }

    fun state(): String {
        val c = primary() ?: return JSONObject().put("st", "end").toString()
        val st = when (c.state) {
            Call.STATE_RINGING -> "ring"
            Call.STATE_ACTIVE, Call.STATE_HOLDING -> "act"
            Call.STATE_DISCONNECTED, Call.STATE_DISCONNECTING -> "end"
            else -> "dial"
        }
        var t0 = 0L
        if (st == "act") t0 = t0s.getOrPut(c) { val d = c.details.connectTimeMillis; if (d > 0) d else System.currentTimeMillis() }
        val audio = svc?.callAudioState
        val mask = audio?.supportedRouteMask ?: 0
        val rts = JSONArray()
        if ((mask and CallAudioState.ROUTE_EARPIECE) != 0) rts.put("ear")
        if ((mask and CallAudioState.ROUTE_WIRED_HEADSET) != 0) rts.put("wired")
        if ((mask and CallAudioState.ROUTE_BLUETOOTH) != 0) rts.put("bt")
        if ((mask and CallAudioState.ROUTE_SPEAKER) != 0) rts.put("spk")
        val o = JSONObject()
            .put("st", st)
            .put("num", numberOf(c))
            .put("dir", if (c.details.callDirection == Call.Details.DIRECTION_INCOMING) "in" else "out")
            .put("t0", t0)
            .put("mute", audio?.isMuted == true)
            .put("spk", audio?.route == CallAudioState.ROUTE_SPEAKER)
            .put("hold", c.state == Call.STATE_HOLDING)
            .put("conf", (c.details.callProperties and Call.Details.PROPERTY_CONFERENCE) != 0)
            .put("rts", rts)
            .put("rt", when (audio?.route) {
                CallAudioState.ROUTE_EARPIECE -> "ear"; CallAudioState.ROUTE_WIRED_HEADSET -> "wired"
                CallAudioState.ROUTE_BLUETOOTH -> "bt"; CallAudioState.ROUTE_SPEAKER -> "spk"; else -> ""
            })
        top().firstOrNull { it !== c && it.state == Call.STATE_RINGING }?.let { o.put("w", numberOf(it).ifEmpty { "Unknown" }) }
        top().firstOrNull { it !== c && it.state == Call.STATE_HOLDING }?.let { o.put("hd", numberOf(it).ifEmpty { "Unknown" }) }
        return o.toString()
    }
}
