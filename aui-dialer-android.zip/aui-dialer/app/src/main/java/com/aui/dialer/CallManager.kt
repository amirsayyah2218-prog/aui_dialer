package com.aui.dialer

import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import org.json.JSONObject

/** Holds the active telecom call and exposes controls + a JSON state for the web UI. */
object CallManager {
    private var call: Call? = null
    private var svc: InCallService? = null
    private var t0 = 0L
    private val listeners = LinkedHashSet<() -> Unit>()
    @Volatile var uiUp = false

    fun listen(l: () -> Unit) { listeners.add(l) }
    fun unlisten(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { listeners.toList().forEach { it() } }

    fun add(s: InCallService, c: Call) { svc = s; call = c; t0 = 0; notifyChanged() }
    fun remove(c: Call) { if (call === c) call = null; notifyChanged() }

    fun answer() { call?.answer(VideoProfile.STATE_AUDIO_ONLY) }
    fun hangup() {
        val c = call ?: return
        if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
    }
    fun rejectWithMessage(t: String) { call?.reject(true, t) }
    fun hold(on: Boolean) { if (on) call?.hold() else call?.unhold() }
    @Suppress("DEPRECATION")
    fun mute(on: Boolean) { svc?.setMuted(on) }
    @Suppress("DEPRECATION")
    fun speaker(on: Boolean) {
        svc?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
    }
    fun dtmf(k: String) {
        val c = call ?: return
        val ch = k.firstOrNull() ?: return
        c.playDtmfTone(ch)
        Handler(Looper.getMainLooper()).postDelayed({ c.stopDtmfTone() }, 150)
    }

    @Suppress("DEPRECATION")
    fun state(): String {
        val c = call ?: return JSONObject().put("st", "end").toString()
        val st = when (c.state) {
            Call.STATE_RINGING -> "ring"
            Call.STATE_ACTIVE, Call.STATE_HOLDING -> "act"
            Call.STATE_DISCONNECTED, Call.STATE_DISCONNECTING -> "end"
            else -> "dial"
        }
        if (st == "act" && t0 == 0L) {
            val d = c.details.connectTimeMillis
            t0 = if (d > 0) d else System.currentTimeMillis()
        }
        val audio = svc?.callAudioState
        return JSONObject()
            .put("st", st)
            .put("num", c.details.handle?.schemeSpecificPart ?: "")
            .put("dir", if (c.details.callDirection == Call.Details.DIRECTION_INCOMING) "in" else "out")
            .put("t0", t0)
            .put("mute", audio?.isMuted == true)
            .put("spk", audio?.route == CallAudioState.ROUTE_SPEAKER)
            .put("hold", c.state == Call.STATE_HOLDING)
            .toString()
    }
}
