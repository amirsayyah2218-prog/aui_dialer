# AUI Dialer (Android)

Glass-theme dialer + contacts app. UI = `app/src/main/assets/index.html` (web); native layer = Kotlin
(WebView + JS bridge, `InCallService` for real calls, Contacts/CallLog providers).

## Build
**Android Studio (easiest):** File → Open → this folder → wait for Gradle sync → Run ▶ (device with Android 10+).
**GitHub:** push this folder to a repo → Actions → "Build APK" → download `aui-dialer-debug` artifact.
**CLI:** `gradle assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34) → `app/build/outputs/apk/debug/`.

## First run
1. Allow the permission prompts (contacts, call log, phone, SMS, notifications).
2. Accept "Set as default phone app" — required for the custom call screens and incoming-call UI.
   Later: ⋮ → Settings → Set as default phone app.

## Notes
- Contact photos aren't imported yet (initials shown). Call recording is blocked by Android.
- Google Fonts load online; to go offline put .woff2 files in `assets/` and reference them in the CSS.
